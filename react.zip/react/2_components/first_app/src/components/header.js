import React from 'react';

function Header() {
	return <h1> Header </h1>
}

export { Header };