import React, { Component } from 'react';
import '../../List.css';
var FontAwesome = require('react-fontawesome');

class EmployeeList extends Component {

    employeeClicked = employee => evt => {
        this.props.employeeClicked(employee);
    };

	updateClicked = employee => evt => {
        this.props.updateClicked(employee);
    };

	deleteClicked = employee => evt => {
        console.log('delete click');
		fetch(`http://127.0.0.1:8000/api/employees/${employee.id}/`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${this.props.token}`
            }
        })
        .then( res => this.props.reload(employee, 'delete'))
        .catch( error => console.log(error))
    };

	render() {
		return (
			<div>
                <h1> Employees List </h1> 
				{ 
					this.props.employees.map(employee => {
						return (
							<div key={ employee.id } className="List">
								<h3 onClick={this.employeeClicked(employee)}> { employee.name } </h3>
								<FontAwesome name="edit" onClick={this.updateClicked(employee)}/>
								<FontAwesome name="trash" onClick={this.deleteClicked(employee)}/>
							</div>
						)
					})
				}
			</div>
		)
	}
}

export default EmployeeList;