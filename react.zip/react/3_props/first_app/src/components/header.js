import React from 'react';

function Header(props) {
	return (
		<div>
			<h1> { props.message } </h1>
			<h1> Our { props.name } page </h1>
		</div>
	)
}

export { Header };