import React, { Component } from 'react';
import {Text, View, StyleSheet} from 'react-native';

class List extends Component {

    render() {
        return (
            <View style={styles.container}>
                <View style={{ marginBottom:20, height: 100, alignItems:"center", justifyContent: "center"}}>
                    <Text style={{fontSize:20, fontWeight:'bold'}}> Employee List </Text>
                </View>
            </View>
        );
    }
}

List.navigationOptions = {
    title: "Home Screen",
    headerStyle: {
      backgroundColor: '#714B67'
    },
    headerTintColor: '#fff',
}

const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
    }
})  

export default List;