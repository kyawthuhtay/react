import './App.css';
import { Header } from './components/header.js';
import Footer from './components/footer.js';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          <Header message="header page" name="testing" />
          {/* <Header message="header page" /> */}
            main page
          <Footer address="yangon" />
        </p>
      </header>
    </div>
  );
}

export default App;