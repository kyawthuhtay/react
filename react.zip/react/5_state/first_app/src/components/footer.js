import React, { Component } from 'react';

class Footer extends Component {
	state = {
		name: 'aungaung',
		address: 'yangon'
	}

	showAddress() {
		alert('you click yangon !');
	}

	logConsole() {
		console.log('you typed in footer ...');
	}

	logConsoles(evt) {
		console.log(evt);
	}

	logConsoless(evt) {
		console.log(this.state.name);
	}

	logConsolesss = (evt) => {
		console.log(this.state.name);
	}

	logConsolessss = evt => {
		console.log(evt.target.value);
	}

	logConsolesssss = evt => {
		console.log(evt.target.value);
		this.setState({name: evt.target.value});
	}

	render() {
		return (
			<div>
				<h2 onClick={ this.showAddress }> 
					{ this.props.address } 
				</h2>
				<input onChange={ this.logConsole } type="text" />

				<div>
					<p> { this.state.name } live in { this.state.address } </p>
				</div>

				<div>
					evt <input value={ this.state.name } onChange={ this.logConsoles } type="text" />
				</div>
				
				<div>
					bind <input value={ this.state.name } onChange={ this.logConsoless.bind(this) } type="text" />
				</div>

				<div>
					=> <input value={ this.state.name } onChange={ this.logConsolesss } type="text" />
				</div>

				<div>
					target <input value={ this.state.name } onChange={ this.logConsolessss } type="text" />
				</div>
				
				<div>
					setState <input value={ this.state.name } onChange={ this.logConsolesssss } type="text" />
				</div>
				
			</div>
		)
	}
}

export default Footer;