import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './login.js';
import Home from './home.js';
import { CookiesProvider } from "react-cookie";

const Menu = () => {
  return (
    <CookiesProvider>
      <BrowserRouter>
        <Routes>
            <Route path="" element={<Login />} />
            <Route path="home" element={<Home />} />
        </Routes>
      </BrowserRouter>
    </CookiesProvider>
  )
};

export default Menu;