import React, { Component } from 'react';

class EmployeeForm extends Component {

    state = {
		editedEmployee: null
	}

    inputChanged = evt => {
        console.log('input change', evt.target.value);
        let employee = this.props.employee;
        employee[evt.target.name] = evt.target.value;
        this.setState({ editedEmployee: employee });
    }

    save = () => {
        console.log('save click');
        fetch('http://127.0.0.1:8000/api/employees/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${this.props.token}`
            },
            body: JSON.stringify(this.state.editedEmployee)
        }).then( resp => resp.json())
        .then( res => this.props.reload(res, 'save'))
        .catch( error => console.log(error))
    }

    update = () => {
        console.log('update click');
        fetch(`http://127.0.0.1:8000/api/employees/${this.props.employee.id}/`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${this.props.token}`
            },
            body: JSON.stringify(
                this.state.editedEmployee
            )
        }).then( resp => resp.json())
        .then( res => this.props.reload(res, 'update'))
        .catch( error => console.log(error))
    }

	render() {
		return (
			<div>
                <h1> Form View </h1> 
                <div>
                    <span> Name </span> <br/>
                    <input name="name" value={this.props.employee.name} type="text" onChange={this.inputChanged}/> <br/>
                    <span> Phone </span> <br/>
                    <input name="phone" value={this.props.employee.phone} type="text" onChange={this.inputChanged} /> <br/>
                    <span> Address </span> <br/>
                    <input name="address" value={this.props.employee.address} type="text" onChange={this.inputChanged} /> <br/>
                    { this.props.view_type == 'create' ? <button onClick={this.save}> Save </button> : null }
                    { this.props.view_type == 'update' ? <button onClick={this.update}> Update </button> : null}
                </div>
			</div>
		)
	}
}

export default EmployeeForm;