//employees
import List from './components/employees/list';
import Detail from './components/employees/detail';
import Form from './components/employees/form';

//example for expenses
import ExpenseList from './components/employees/list';
import ExpenseDetail from './components/employees/detail';
import ExpenseForm from './components/employees/form';

import Login from './components/login';

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createDrawerNavigator, DrawerItems } from 'react-navigation-drawer';
import { createStackNavigator } from 'react-navigation-stack';

import Icon from 'react-native-vector-icons/Ionicons';  
import { Text, View } from "react-native";

const AppNavigator = createStackNavigator(
  {
    List: {screen: List},
    Detail: {screen: Detail},
    Form: {screen: Form},
    Login: {screen: Login}
  },  
  // {  
  //   initialRouteName: "Login"  
  // },
  {  
    defaultNavigationOptions: ({ navigation }) => {  
      return {  
        headerLeft: (  
          <Icon  
              style={{ paddingLeft: 10 }}  
              onPress={() => navigation.openDrawer()}  
              name="md-menu"  
              size={30}  
          />  
        )  
      };  
    }  
  }  
);

const ExpenseAppNavigator = createStackNavigator(
  {
    List: {screen: ExpenseList},
    Detail: {screen: ExpenseDetail},
    Form: {screen: ExpenseForm}
  },  
  {  
    defaultNavigationOptions: ({ navigation }) => {  
      return {  
        headerLeft: (  
          <Icon  
              style={{ paddingLeft: 10 }}  
              onPress={() => navigation.openDrawer()}  
              name="md-menu"  
              size={30}  
          />  
        )  
      };  
    }  
  }  
);

const AppDrawerNavigator = createDrawerNavigator({  
    Employees: {  
      screen: AppNavigator  
    },
    Expenses: {  
      screen: ExpenseAppNavigator  
    },
  },
  {
    contentComponent: (props) => (
      <View>
        <View style={{height: 100, alignItems: 'center', justifyContent: 'center'}}>
          <Text style={{fontSize: 45}}> HRMS </Text>
        </View>
        <View>
          <DrawerItems {...props} />
        </View>
      </View>
    )
  }
);  

const AppSwitchNavigator = createSwitchNavigator({  
  StartPage: { screen: List }, 
  HomePage: { screen: AppDrawerNavigator },  
});

const App = createAppContainer(AppSwitchNavigator);

export default App;