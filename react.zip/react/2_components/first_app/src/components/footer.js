import React, { Component } from 'react';

class Footer extends Component {
	render() {
		return <h1> Footer </h1>
	}
}

export default Footer;