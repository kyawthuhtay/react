import React from 'react';

function logConsole() {
	console.log('you typed in header ...');
}

function Header(props) {
	return (
		<div>
			<h1> { props.message } </h1>
			<h1 onClick={ props.popup }> Our { props.name } page </h1>
			<input onChange={ logConsole } type="text" />
		</div>
	)
}

export { Header };