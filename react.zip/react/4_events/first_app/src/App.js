import './App.css';
import { Header } from './components/header.js';
import Footer from './components/footer.js';

function showTesting() {
  alert('you click testing !');
}

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          <Header message="header page" name="testing" popup={ showTesting } />
            main page
          <Footer address="yangon" />
        </p>
      </header>
    </div>
  );
}

export default App;