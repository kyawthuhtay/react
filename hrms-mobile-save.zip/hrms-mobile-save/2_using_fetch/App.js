import List from './components/employees/list';
import Detail from './components/employees/detail';
import Form from './components/employees/form';
import Login from './components/login';

import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

const AppNavigator = createStackNavigator(
  {
    List: {screen: List},
    Detail: {screen: Detail},
    Form: {screen: Form},
    Login: {screen: Login},
  },  
  {  
    initialRouteName: "List"  
  }
)

const App = createAppContainer(AppNavigator);

export default App;