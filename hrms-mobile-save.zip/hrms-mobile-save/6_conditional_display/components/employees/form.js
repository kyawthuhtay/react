import React, { Component } from 'react';
import {Text, View, StyleSheet, TextInput, Button} from 'react-native';

class Form extends Component {

    state = {
        editedEmployee: null
    }

    inputChanged = (name, value) => {
        console.log('input change', name, value);
        employee = this.props.navigation.getParam('employee', '');
        employee[name] = value;
        this.setState({ editedEmployee: employee });
    }

    save = () => {
        console.log('save click');
    }  
        
    update = () => {
        console.log('update click');
    }

    render() {
        employee = this.props.navigation.getParam('employee', '');
        view_type = this.props.navigation.getParam('view_type', '');

        return (
            <View style={styles.container}>
                <View style={{ marginBottom:20, height: 100, alignItems:"center", justifyContent: "center"}}>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20}}> Employee Form </Text>
                </View>

                <TextInput 
                    style={styles.inputText} 
                    value={employee.name} 
                    onChangeText={value => this.inputChanged('name', value)}
                    />

                <TextInput 
                    style={styles.inputText} 
                    value={employee.phone} 
                    onChangeText={value => this.inputChanged('phone', value)}
                    />

                <TextInput 
                    style={styles.inputText} 
                    value={employee.address} 
                    onChangeText={value => this.inputChanged('address', value)}
                    />
                
                <View style={{ width: '80%'}}>
                    {
                        view_type ? <Button onPress={this.save} title="Save" /> : <Button onPress={this.update} title="Update" />
                    }
                </View>
            </View>
        );
    }
}

Form.navigationOptions = {
    title: "Form Screen",
    headerStyle: {
      backgroundColor: 'green'
    },
    headerTintColor: '#fff',
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
    },
    inputText: {
      height: 50,
      padding: 10,
      height: 45,
      width: "80%",
      borderRadius: 10,
      marginBottom: 20,
      borderColor: 'blue', 
      borderWidth: 1
    },
});

export default Form;