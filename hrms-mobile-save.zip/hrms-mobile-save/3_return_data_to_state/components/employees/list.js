import React, { Component } from 'react';
import {Text, View, StyleSheet, FlatList} from 'react-native';

class List extends Component {

    state = {
        employees: []
    }

    componentDidMount() {
        console.log('componentDidMount call');
        fetch('http://192.168.99.175:8000/api/employees/', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Token 5bfc020cdc3bbe1f3e399fe2c5727c6c7e85c28a'
            }
        })
        .then( resp => resp.json())
        .then( res => this.setState({employees: res}))
        .catch( error => console.log(error))
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={{ marginBottom:20, height: 100, alignItems:"center", justifyContent: "center"}}>
                    <Text style={{fontSize:20, fontWeight:'bold'}}> Employee List </Text>
                </View>
                <FlatList 
                    data={this.state.employees}
                    renderItem={({item, index}) => (
                        <Text style={[
                            { padding: 10, fontSize: 18, height: 44,backgroundColor: 'white', flex: 1 }, 
                            index % 2 == 0 ? { backgroundColor: '#D3D3D3' } : { backgroundColor: 'white' } 
                        ]}>
                            {item.name}
                        </Text> 
                    )}
                />
            </View>
        );
    }
}

List.navigationOptions = {
    title: "Home Screen",
    headerStyle: {
      backgroundColor: '#714B67'
    },
    headerTintColor: '#fff',
}

const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
    },  
    item: {  
        padding: 10,  
        fontSize: 18,  
        height: 44
    },  
})  

export default List;