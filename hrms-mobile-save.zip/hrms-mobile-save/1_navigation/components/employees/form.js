import React, { Component } from 'react';
import {Text, View, StyleSheet} from 'react-native';

class Form extends Component {

    render() {
        return (
            <View style={styles.container}>
                <View style={{ marginBottom:20, height: 100, alignItems:"center", justifyContent: "center"}}>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20}}> Employee Form </Text>
                </View>
            </View>
        );
    }
}

Form.navigationOptions = {
    title: "Form Screen",
    headerStyle: {
      backgroundColor: 'green'
    },
    headerTintColor: '#fff',
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
    }
});

export default Form;