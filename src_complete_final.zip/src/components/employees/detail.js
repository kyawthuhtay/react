import React, { Component } from 'react';

class EmployeeDetail extends Component {

	render() {
        const employee = this.props.employee;
		return (
			<div>
                <h1> Detail View </h1> 
                <div>
                    <h3> {employee.name} </h3>
                    <p> {employee.phone} </p>
                    <p> {employee.address} </p>
                </div>
			</div>
		)
	}
}

export default EmployeeDetail;