import React, { Component } from 'react';

class Footer extends Component {
	render() {
		return <h2> { this.props.address } </h2>
	}
}

export default Footer;