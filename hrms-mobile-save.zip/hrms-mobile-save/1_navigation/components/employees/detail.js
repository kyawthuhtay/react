import { Component } from 'react';
import {Text, View, StyleSheet} from 'react-native';

class Detail extends Component {

    render() {
        return (
            <View style={styles.container}>
                <View style={{ marginBottom:20, height: 100, alignItems:"center", justifyContent: "center"}}>
                    <Text style={{fontSize:20, fontWeight:'bold'}}> Employee Detail </Text>
                </View>
            </View>
        );
    }
}

Detail.navigationOptions = {
    title: "Detail Screen",
    headerStyle: {
      backgroundColor: 'orange'
    },
    headerTintColor: '#fff'
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
    }
});

export default Detail;