import React, { Component } from 'react';

class Footer extends Component {
	showAddress() {
		alert('you click yangon !');
	}

	logConsole() {
		console.log('you typed in footer ...');
	}

	render() {
		return (
			<div>
				<h2 onClick={ this.showAddress }> 
					{ this.props.address } 
				</h2>
				<input onChange={ this.logConsole } type="text" />
			</div>
		)
	}
}

export default Footer;