import React, { Component } from 'react';
import EmployeeList from './employees/list.js';
import EmployeeDetail from './employees/detail.js';
import EmployeeForm from './employees/form.js';
import '../Home.css';
import { withCookies } from 'react-cookie';

class Home extends Component {

	state = {
		employees: [],
		selectedEmployee: null,
		view_type: '',
		token: this.props.cookies.get('mr-token')
	}

	componentDidMount(){
		console.log(`Token ${this.state.token}`);
		fetch('http://127.0.0.1:8000/api/employees/', {
			method: 'GET',
			headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${this.state.token}`
            }
		})
		.then( resp => resp.json())
		.then( res => this.setState({employees: res}))
		.catch( error => console.log(error))
	}

	employeeClicked = employee => {
		console.log("Employee Click");
		this.setState({selectedEmployee: employee, view_type: 'detail' });
	}

	addNewClicked = () => {
        console.log("Add New Click");
		let newemployee = {
			'name': '',
			'phone': '',
			'address': ''
		};
		this.setState({selectedEmployee: newemployee, view_type: 'create'});
    };

	updateClicked = employee => {
        console.log("update Click");
		this.setState({selectedEmployee: employee, view_type: 'update'});
    };

	reload = (employee, method) => {
		if (method == 'save') {
			this.setState({employees: [...this.state.employees, employee]});
		} else if (method == 'update') {
			this.setState({view_type: ''});
		} else if (method == 'delete') {
			const employees = this.state.employees.filter( emp => emp.id !== employee.id);
    		this.setState({employees: employees});
		}
	}

	render() {
		return (
			<div>
				<h1> HRMS </h1>
				<div className="Header">
					<EmployeeList employees={ this.state.employees } employeeClicked={this.employeeClicked} updateClicked={this.updateClicked} reload={this.reload} token={this.state.token}/>
					{ 
						this.state.view_type == 'create' || this.state.view_type == 'update'
						?
							<EmployeeForm employee={ this.state.selectedEmployee } view_type={ this.state.view_type } reload={this.reload} token={this.state.token}/>
						:
							null
					}

					{ this.state.view_type == 'detail' ? <EmployeeDetail employee={ this.state.selectedEmployee } /> : null }
				</div>
				<div className="Footer">
					<button onClick={this.addNewClicked}>Add New</button>
				</div>
			</div>
		)
	}
}

export default withCookies(Home);