import React, { Component } from 'react';
import { withCookies } from "react-cookie";

class Login extends Component {

	state = {
		user: {
            username: '',
            password: ''
        },
	}

	inputChanged = event => {
        let user = this.state.user;
        user[event.target.name] = event.target.value;
        this.setState({user: user});
    }

	clickLogin  = () =>  {
		fetch('http://127.0.0.1:8000/auth/', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json'},
			body: JSON.stringify(this.state.user)
		})
		.then( resp => resp.json())
		.then( res => {
				console.log(res.token);
				this.props.cookies.set('mr-token', res.token);
				if (res.token) {
					window.location.href = "/home";
				} else {
					alert("Username & Password Invalid !");
				}
		}).catch( error => console.log(error))
	}

	render() {
		return (
			<div className="Login">
				<div>
					<div>
						username : <input name="username" onChange={ this.inputChanged } type="text" />
					</div>
					<div>
						password : <input name="password" onChange={ this.inputChanged } type="text" />
					</div>
					<div>
						<button onClick={ this.clickLogin }> Login </button>
					</div>
				</div>

			</div>
		)
	}
}

export default withCookies(Login);